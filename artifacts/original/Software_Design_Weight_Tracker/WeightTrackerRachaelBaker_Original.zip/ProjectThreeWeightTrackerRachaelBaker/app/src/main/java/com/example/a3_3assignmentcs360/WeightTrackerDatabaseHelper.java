package com.example.a3_3assignmentcs360;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class WeightTrackerDatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "smart_weight_tracker.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_USERS = "users";
    private static final String TABLE_DAILY_WEIGHTS = "daily_weights";
    private static final String TABLE_GOAL_WEIGHTS = "goal_weights";

    public WeightTrackerDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // The three tables keep account, daily weight, and goal data separated but connected.
        db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "username TEXT UNIQUE NOT NULL, "
                + "password TEXT NOT NULL)");

        db.execSQL("CREATE TABLE " + TABLE_DAILY_WEIGHTS + " ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "user_id INTEGER NOT NULL, "
                + "entry_date TEXT NOT NULL, "
                + "weight REAL NOT NULL, "
                + "FOREIGN KEY(user_id) REFERENCES " + TABLE_USERS + "(id))");

        db.execSQL("CREATE TABLE " + TABLE_GOAL_WEIGHTS + " ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "user_id INTEGER UNIQUE NOT NULL, "
                + "goal_weight REAL NOT NULL, "
                + "FOREIGN KEY(user_id) REFERENCES " + TABLE_USERS + "(id))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DAILY_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    public long createUser(String username, String password) {
        // Store a hashed password instead of the plain text value the user typed.
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", hashPassword(password));
        return getWritableDatabase().insert(TABLE_USERS, null, values);
    }

    public long validateUser(String username, String password) {
        String[] columns = {"id"};
        String selection = "username = ? AND password = ?";
        String[] args = {username, hashPassword(password)};

        try (Cursor cursor = getReadableDatabase().query(TABLE_USERS, columns, selection, args, null, null, null)) {
            if (cursor.moveToFirst()) {
                return cursor.getLong(0);
            }
        }

        return -1;
    }

    public long addWeight(long userId, String entryDate, double weight) {
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("entry_date", entryDate);
        values.put("weight", weight);
        return getWritableDatabase().insert(TABLE_DAILY_WEIGHTS, null, values);
    }

    public int updateWeight(long entryId, String entryDate, double weight) {
        ContentValues values = new ContentValues();
        values.put("entry_date", entryDate);
        values.put("weight", weight);
        return getWritableDatabase().update(TABLE_DAILY_WEIGHTS, values, "id = ?", new String[]{String.valueOf(entryId)});
    }

    public int deleteWeight(long entryId) {
        return getWritableDatabase().delete(TABLE_DAILY_WEIGHTS, "id = ?", new String[]{String.valueOf(entryId)});
    }

    public List<WeightEntry> getWeights(long userId) {
        // The dashboard needs the newest entries first so the latest progress is easy to see.
        List<WeightEntry> weights = new ArrayList<>();
        String[] columns = {"id", "entry_date", "weight"};
        String selection = "user_id = ?";
        String[] args = {String.valueOf(userId)};

        try (Cursor cursor = getReadableDatabase().query(TABLE_DAILY_WEIGHTS, columns, selection, args, null, null, "entry_date DESC, id DESC")) {
            while (cursor.moveToNext()) {
                weights.add(new WeightEntry(cursor.getLong(0), cursor.getString(1), cursor.getDouble(2)));
            }
        }

        return weights;
    }

    public WeightEntry getWeight(long entryId) {
        String[] columns = {"id", "entry_date", "weight"};
        try (Cursor cursor = getReadableDatabase().query(TABLE_DAILY_WEIGHTS, columns, "id = ?", new String[]{String.valueOf(entryId)}, null, null, null)) {
            if (cursor.moveToFirst()) {
                return new WeightEntry(cursor.getLong(0), cursor.getString(1), cursor.getDouble(2));
            }
        }

        return null;
    }

    public void saveGoalWeight(long userId, double goalWeight) {
        // Each user only needs one active goal, so this updates the existing goal when possible.
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("goal_weight", goalWeight);

        SQLiteDatabase db = getWritableDatabase();
        int updated = db.update(TABLE_GOAL_WEIGHTS, values, "user_id = ?", new String[]{String.valueOf(userId)});
        if (updated == 0) {
            db.insert(TABLE_GOAL_WEIGHTS, null, values);
        }
    }

    public Double getGoalWeight(long userId) {
        String[] columns = {"goal_weight"};
        try (Cursor cursor = getReadableDatabase().query(TABLE_GOAL_WEIGHTS, columns, "user_id = ?", new String[]{String.valueOf(userId)}, null, null, null)) {
            if (cursor.moveToFirst()) {
                return cursor.getDouble(0);
            }
        }

        return null;
    }

    private String hashPassword(String password) {
        // This is a basic local hash for the class project, not a full production login system.
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder builder = new StringBuilder();
            for (byte value : hashedBytes) {
                builder.append(String.format(Locale.US, "%02x", value));
            }
            return builder.toString();
        } catch (NoSuchAlgorithmException error) {
            throw new IllegalStateException("SHA-256 is not available on this device.", error);
        }
    }
}
