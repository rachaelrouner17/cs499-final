package com.example.a3_3assignmentcs360;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_REQUEST = 100;
    private static final String PREFS_NAME = "smart_weight_tracker_prefs";
    private static final String PREF_PHONE = "notification_phone";

    private WeightTrackerDatabaseHelper databaseHelper;
    private long activeUserId = -1;
    private long editingWeightId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        databaseHelper = new WeightTrackerDatabaseHelper(this);
        setContentView(R.layout.activity_main);
    }

    public void loginUser(View view) {
        // The login screen keeps the user out of the tracking screens until the account is verified.
        EditText usernameInput = findViewById(R.id.usernameInput);
        EditText passwordInput = findViewById(R.id.passwordInput);
        TextView statusText = findViewById(R.id.loginStatusText);

        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            statusText.setText("Enter a username and password.");
            return;
        }

        long userId = databaseHelper.validateUser(username, password);
        if (userId < 0) {
            statusText.setText("Login not found. Create a new login first.");
            return;
        }

        activeUserId = userId;
        showDashboard(view);
    }

    public void createAccount(View view) {
        // New accounts are saved locally so the user can come back to the app later.
        EditText usernameInput = findViewById(R.id.usernameInput);
        EditText passwordInput = findViewById(R.id.passwordInput);
        TextView statusText = findViewById(R.id.loginStatusText);

        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            statusText.setText("Choose a username and password.");
            return;
        }

        long userId = databaseHelper.createUser(username, password);
        if (userId < 0) {
            statusText.setText("That username already exists. Try logging in.");
            return;
        }

        activeUserId = userId;
        showDashboard(view);
    }

    public void showDashboard(View view) {
        setContentView(R.layout.activity_dashboard);
        populateDashboard();
    }

    public void showAddWeight(View view) {
        editingWeightId = -1;
        setContentView(R.layout.activity_add_weight);

        // Most users will log today's weight, so the date is filled in for convenience.
        EditText dateInput = findViewById(R.id.weightDateInput);
        String today = new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(new Date());
        dateInput.setText(today);
    }

    public void showGoalWeight(View view) {
        setContentView(R.layout.activity_goal_weight);
        Double goalWeight = databaseHelper.getGoalWeight(activeUserId);
        EditText goalInput = findViewById(R.id.goalWeightInput);
        if (goalWeight != null) {
            goalInput.setText(formatWeight(goalWeight));
        }
    }

    public void showProgress(View view) {
        setContentView(R.layout.activity_progress);
        updateProgressScreen();
    }

    public void showSettings(View view) {
        setContentView(R.layout.activity_sms_permission);

        EditText phoneInput = findViewById(R.id.phoneNumberInput);
        phoneInput.setText(getSavedPhoneNumber());
        updateSmsStatus();
    }

    public void saveWeightEntry(View view) {
        TextView statusText = findViewById(R.id.weightStatusText);
        EditText dateInput = findViewById(R.id.weightDateInput);
        EditText weightInput = findViewById(R.id.dailyWeightInput);

        String entryDate = dateInput.getText().toString().trim();
        String weightText = weightInput.getText().toString().trim();

        if (entryDate.isEmpty() || weightText.isEmpty()) {
            statusText.setText("Enter both date and weight.");
            return;
        }

        double weight;
        try {
            weight = Double.parseDouble(weightText);
        } catch (NumberFormatException error) {
            statusText.setText("Weight must be a number.");
            return;
        }

        // The same screen is used for both adding a new weight and updating an existing one.
        if (editingWeightId >= 0) {
            databaseHelper.updateWeight(editingWeightId, entryDate, weight);
            editingWeightId = -1;
        } else {
            databaseHelper.addWeight(activeUserId, entryDate, weight);
        }

        // After saving, the dashboard refreshes so the user immediately sees the latest data.
        sendGoalSmsIfNeeded(weight);
        showDashboard(view);
    }

    public void saveGoalWeight(View view) {
        TextView statusText = findViewById(R.id.goalStatusText);
        EditText goalInput = findViewById(R.id.goalWeightInput);
        String goalText = goalInput.getText().toString().trim();

        if (goalText.isEmpty()) {
            statusText.setText("Enter a goal weight.");
            return;
        }

        try {
            double goalWeight = Double.parseDouble(goalText);
            databaseHelper.saveGoalWeight(activeUserId, goalWeight);
            showDashboard(view);
        } catch (NumberFormatException error) {
            statusText.setText("Goal weight must be a number.");
        }
    }

    public void requestSmsPermission(View view) {
        // Save the phone number first so permission and notification setup happen in one flow.
        saveNotificationPhone(view);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            updateSmsStatusText("SMS permission is enabled. Goal weight notifications can be sent.");
            return;
        }

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST);
    }

    public void declineSmsPermission(View view) {
        updateSmsStatusText("SMS permission declined. The app will still track weight, but text notifications will stay off.");
    }

    public void saveNotificationPhone(View view) {
        EditText phoneInput = findViewById(R.id.phoneNumberInput);
        String phone = phoneInput.getText().toString().trim();
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putString(PREF_PHONE, phone).apply();
        updateSmsStatusText("Phone number saved. SMS notifications require permission to send.");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                updateSmsStatusText("SMS permission granted. A text can be sent when the goal weight is reached.");
            } else {
                updateSmsStatusText("SMS permission denied. The app remains usable without text notifications.");
            }
        }
    }

    private void populateDashboard() {
        // Rebuild the grid from the database each time so edits and deletes stay in sync.
        TextView progressSummary = findViewById(R.id.progressSummary);
        TableLayout weightGrid = findViewById(R.id.weightGrid);
        List<WeightEntry> weights = databaseHelper.getWeights(activeUserId);
        Double goalWeight = databaseHelper.getGoalWeight(activeUserId);

        removeDynamicRows(weightGrid);

        for (WeightEntry entry : weights) {
            weightGrid.addView(createWeightRow(entry));
        }

        if (weights.isEmpty()) {
            progressSummary.setText("Goal: " + formatGoal(goalWeight) + " • Latest entry: no entries yet");
        } else {
            WeightEntry latest = weights.get(0);
            progressSummary.setText("Goal: " + formatGoal(goalWeight)
                    + " • Latest entry: " + formatWeight(latest.getWeight()) + " lb"
                    + " • " + buildGoalMessage(goalWeight, latest.getWeight()));
        }
    }

    private TableRow createWeightRow(WeightEntry entry) {
        // Each database row gets a matching table row with simple edit and delete actions.
        TableRow row = new TableRow(this);
        row.addView(createTableCell(entry.getEntryDate(), 1));
        row.addView(createTableCell(formatWeight(entry.getWeight()) + " lb", 1));

        Button editButton = createActionButton("Edit");
        editButton.setOnClickListener(v -> editWeightEntry(entry.getId()));

        Button deleteButton = createActionButton("Delete");
        deleteButton.setTextColor(ContextCompat.getColor(this, R.color.danger_red));
        deleteButton.setOnClickListener(v -> {
            databaseHelper.deleteWeight(entry.getId());
            populateDashboard();
        });

        TableRow.LayoutParams actionParams = new TableRow.LayoutParams(dpToPx(104), TableRow.LayoutParams.WRAP_CONTENT);
        android.widget.LinearLayout actionLayout = new android.widget.LinearLayout(this);
        actionLayout.setOrientation(android.widget.LinearLayout.VERTICAL);
        actionLayout.setLayoutParams(actionParams);
        actionLayout.setBackgroundResource(R.drawable.table_cell_border);
        actionLayout.addView(editButton);
        actionLayout.addView(deleteButton);
        row.addView(actionLayout);

        return row;
    }

    private TextView createTableCell(String text, int weight) {
        TextView cell = new TextView(this);
        TableRow.LayoutParams params = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, weight);
        cell.setLayoutParams(params);
        cell.setBackgroundResource(R.drawable.table_cell_border);
        cell.setText(text);
        cell.setTextColor(ContextCompat.getColor(this, R.color.primary_blue_dark));
        cell.setTextSize(15);
        return cell;
    }

    private Button createActionButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(12);
        button.setAllCaps(false);
        button.setMinHeight(0);
        button.setMinimumHeight(0);
        button.setPadding(4, 0, 4, 0);
        return button;
    }

    private void editWeightEntry(long entryId) {
        // Loading the saved entry into the form lets the user fix a typo without retyping everything.
        WeightEntry entry = databaseHelper.getWeight(entryId);
        if (entry == null) {
            return;
        }

        editingWeightId = entryId;
        setContentView(R.layout.activity_add_weight);
        TextView title = findViewById(R.id.addWeightTitle);
        EditText dateInput = findViewById(R.id.weightDateInput);
        EditText weightInput = findViewById(R.id.dailyWeightInput);

        title.setText("Update Daily Weight");
        dateInput.setText(entry.getEntryDate());
        weightInput.setText(formatWeight(entry.getWeight()));
    }

    private void updateProgressScreen() {
        TextView currentWeightSummary = findViewById(R.id.currentWeightSummary);
        TextView goalWeightSummary = findViewById(R.id.goalWeightSummary);
        TextView progressMessage = findViewById(R.id.progressMessage);
        List<WeightEntry> weights = databaseHelper.getWeights(activeUserId);
        Double goalWeight = databaseHelper.getGoalWeight(activeUserId);

        if (weights.isEmpty()) {
            currentWeightSummary.setText("Current weight: no entries yet");
            goalWeightSummary.setText("Goal weight: " + formatGoal(goalWeight));
            progressMessage.setText("Add a daily weight to begin tracking progress.");
            return;
        }

        double latestWeight = weights.get(0).getWeight();
        currentWeightSummary.setText("Current weight: " + formatWeight(latestWeight) + " lb");
        goalWeightSummary.setText("Goal weight: " + formatGoal(goalWeight));
        progressMessage.setText(buildGoalMessage(goalWeight, latestWeight));
    }

    private void sendGoalSmsIfNeeded(double latestWeight) {
        // SMS is optional, so the app checks the goal, phone number, and permission before sending.
        Double goalWeight = databaseHelper.getGoalWeight(activeUserId);
        String phoneNumber = getSavedPhoneNumber();
        boolean hasPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;

        if (goalWeight == null || latestWeight > goalWeight || phoneNumber.isEmpty() || !hasPermission) {
            return;
        }

        SmsManager.getDefault().sendTextMessage(
                phoneNumber,
                null,
                "You reached your goal weight. Great job staying consistent!",
                null,
                null
        );
    }

    private void updateSmsStatus() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            updateSmsStatusText("SMS permission is currently enabled.");
        } else {
            updateSmsStatusText("SMS permission is not enabled yet.");
        }
    }

    private void updateSmsStatusText(String message) {
        TextView status = findViewById(R.id.smsPermissionStatus);
        if (status != null) {
            status.setText(message);
        }
    }

    private void removeDynamicRows(TableLayout tableLayout) {
        while (tableLayout.getChildCount() > 1) {
            tableLayout.removeViewAt(1);
        }
    }

    private String getSavedPhoneNumber() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return preferences.getString(PREF_PHONE, "");
    }

    private String formatGoal(Double goalWeight) {
        if (goalWeight == null) {
            return "not set";
        }
        return formatWeight(goalWeight) + " lb";
    }

    private String buildGoalMessage(Double goalWeight, double latestWeight) {
        if (goalWeight == null) {
            return "Set a goal to track progress.";
        }
        if (latestWeight <= goalWeight) {
            return "Goal reached!";
        }
        return formatWeight(latestWeight - goalWeight) + " lb from goal.";
    }

    private String formatWeight(double weight) {
        if (weight == Math.rint(weight)) {
            return String.format(Locale.US, "%.0f", weight);
        }
        return String.format(Locale.US, "%.1f", weight);
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}
