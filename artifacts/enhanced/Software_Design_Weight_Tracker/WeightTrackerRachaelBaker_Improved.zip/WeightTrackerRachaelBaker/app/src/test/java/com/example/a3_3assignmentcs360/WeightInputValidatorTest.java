package com.example.a3_3assignmentcs360;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class WeightInputValidatorTest {

    @Test
    public void acceptsReasonableWeightValues() {
        assertTrue(WeightInputValidator.isValidWeight(160.5));
        assertTrue(WeightInputValidator.isValidWeight(1));
        assertTrue(WeightInputValidator.isValidWeight(1000));
    }

    @Test
    public void rejectsInvalidWeightValues() {
        assertFalse(WeightInputValidator.isValidWeight(0));
        assertFalse(WeightInputValidator.isValidWeight(-10));
        assertFalse(WeightInputValidator.isValidWeight(Double.NaN));
        assertFalse(WeightInputValidator.isValidWeight(1001));
    }

    @Test
    public void acceptsFormattedPhoneNumbers() {
        assertTrue(WeightInputValidator.isValidPhoneNumber("660-334-0590"));
        assertTrue(WeightInputValidator.isValidPhoneNumber("+1 (660) 334-0590"));
    }

    @Test
    public void rejectsIncompletePhoneNumbers() {
        assertFalse(WeightInputValidator.isValidPhoneNumber("12345"));
        assertFalse(WeightInputValidator.isValidPhoneNumber(null));
    }
}
