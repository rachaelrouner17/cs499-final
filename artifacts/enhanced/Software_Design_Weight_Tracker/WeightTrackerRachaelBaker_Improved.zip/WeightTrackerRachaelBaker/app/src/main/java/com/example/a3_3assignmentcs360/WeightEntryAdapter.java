package com.example.a3_3assignmentcs360;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Locale;

/**
 * Binds weight records to reusable rows instead of rebuilding a TableLayout
 * every time the dashboard is refreshed. The callbacks keep navigation and
 * data ownership in MainActivity while this class handles row presentation.
 */
public final class WeightEntryAdapter extends RecyclerView.Adapter<WeightEntryAdapter.EntryViewHolder> {

    public interface OnWeightActionListener {
        void onEdit(WeightEntry entry);

        void onDelete(WeightEntry entry);
    }

    private final List<WeightEntry> entries;
    private final OnWeightActionListener listener;

    public WeightEntryAdapter(List<WeightEntry> entries, OnWeightActionListener listener) {
        this.entries = entries;
        this.listener = listener;
    }

    @NonNull
    @Override
    public EntryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View row = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight_entry, parent, false);
        return new EntryViewHolder(row);
    }

    @Override
    public void onBindViewHolder(@NonNull EntryViewHolder holder, int position) {
        // Bind only the row's data here; activity callbacks handle what happens after a button is pressed.
        WeightEntry entry = entries.get(position);
        holder.dateText.setText(entry.getEntryDate());
        holder.weightText.setText(formatWeight(entry.getWeight()) + " lb");

        String entryDescription = " weight entry for " + entry.getEntryDate();
        holder.editButton.setContentDescription("Edit" + entryDescription);
        holder.deleteButton.setContentDescription("Delete" + entryDescription);

        holder.editButton.setOnClickListener(view -> listener.onEdit(entry));
        holder.deleteButton.setOnClickListener(view -> listener.onDelete(entry));
    }

    @Override
    public int getItemCount() {
        return entries.size();
    }

    private String formatWeight(double weight) {
        // Avoid displaying unnecessary decimals for common whole-number entries.
        if (weight == Math.rint(weight)) {
            return String.format(Locale.US, "%.0f", weight);
        }
        return String.format(Locale.US, "%.1f", weight);
    }

    static final class EntryViewHolder extends RecyclerView.ViewHolder {
        private final TextView dateText;
        private final TextView weightText;
        private final Button editButton;
        private final Button deleteButton;

        EntryViewHolder(@NonNull View itemView) {
            super(itemView);
            // Cache row views once so scrolling does not repeatedly search the layout hierarchy.
            dateText = itemView.findViewById(R.id.entryDateText);
            weightText = itemView.findViewById(R.id.entryWeightText);
            editButton = itemView.findViewById(R.id.editEntryButton);
            deleteButton = itemView.findViewById(R.id.deleteEntryButton);
        }
    }
}
