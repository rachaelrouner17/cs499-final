package com.example.a3_3assignmentcs360;

import android.content.Context;

import java.util.List;

/**
 * Provides one data-access boundary for the Weight Tracker.
 *
 * This keeps database operations out of MainActivity so the activity
 * can focus on screens, navigation, and user interaction. It also
 * makes the data layer easier to test and replace later.
 */
public final class WeightRepository {

    private final WeightTrackerDatabaseHelper database;

    /**
     * Uses the application context so the repository does not hold
     * an unnecessary reference to a screen activity.
     */
    public WeightRepository(Context context) {
        database = new WeightTrackerDatabaseHelper(
                context.getApplicationContext()
        );
    }

    /** Creates a new local user account. */
    public long createUser(String username, String password) {
        return database.createUser(username, password);
    }

    /** Validates login information and returns the user ID when successful. */
    public long validateUser(String username, String password) {
        return database.validateUser(username, password);
    }

    /** Stores a new weight entry for the active user. */
    public long addWeight(long userId, String entryDate, double weight) {
        return database.addWeight(userId, entryDate, weight);
    }

    /** Updates an existing weight entry. */
    public int updateWeight(long userId, long entryId, String entryDate, double weight) {
        return database.updateWeight(userId, entryId, entryDate, weight);
    }

    /** Deletes one weight entry only when it belongs to the active user. */
    public int deleteWeight(long userId, long entryId) {
        return database.deleteWeight(userId, entryId);
    }

    /** Returns all weight entries for the active user. */
    public List<WeightEntry> getWeights(long userId) {
        return database.getWeights(userId);
    }

    /** Returns one weight entry for editing when it belongs to the active user. */
    public WeightEntry getWeight(long userId, long entryId) {
        return database.getWeight(userId, entryId);
    }

    /** Saves or updates the active user's goal weight. */
    public void saveGoalWeight(long userId, double goalWeight) {
        database.saveGoalWeight(userId, goalWeight);
    }

    /** Returns the active user's saved goal weight. */
    public Double getGoalWeight(long userId) {
        return database.getGoalWeight(userId);
    }
}
