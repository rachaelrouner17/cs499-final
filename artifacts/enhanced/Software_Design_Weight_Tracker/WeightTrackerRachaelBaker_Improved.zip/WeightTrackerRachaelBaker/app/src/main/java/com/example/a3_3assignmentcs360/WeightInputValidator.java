package com.example.a3_3assignmentcs360;

/**
 * Centralizes input rules so the screens and automated tests use the same
 * definition of a valid weight and phone number.
 */
public final class WeightInputValidator {
    private WeightInputValidator() {
        // Utility class; no instances are needed.
    }

    public static boolean isValidWeight(double weight) {
        // A finite upper bound catches impossible values and protects database/UI assumptions.
        return Double.isFinite(weight) && weight > 0 && weight <= 1000;
    }

    public static boolean isValidPhoneNumber(String phoneNumber) {
        if (phoneNumber == null) {
            return false;
        }
        // Accept common formatting characters while validating the actual digit count.
        String digitsOnly = phoneNumber.replaceAll("[^0-9]", "");
        return digitsOnly.length() >= 10 && digitsOnly.length() <= 15;
    }
}
