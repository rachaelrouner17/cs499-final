package com.example.a3_3assignmentcs360;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_REQUEST = 100;
    private static final String PREFS_NAME = "smart_weight_tracker_prefs";
    private static final String PREF_PHONE = "notification_phone";

    private WeightTrackerViewModel viewModel;
    private long activeUserId = -1;
    private long editingWeightId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // ViewModel keeps data coordination separate from the activity's screen lifecycle.
        viewModel = new ViewModelProvider(this).get(WeightTrackerViewModel.class);
        setContentView(R.layout.activity_main);
    }

    public void loginUser(View view) {
        // The login screen keeps the user out of the tracking screens until the account is verified.
        EditText usernameInput = findViewById(R.id.usernameInput);
        EditText passwordInput = findViewById(R.id.passwordInput);
        TextView statusText = findViewById(R.id.loginStatusText);

        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        // Give the user a useful message before making a database call when a field is missing.
        if (username.isEmpty() || password.isEmpty()) {
            statusText.setText("Enter a username and password.");
            return;
        }

        long userId = viewModel.validateUser(username, password);
        if (userId < 0) {
            statusText.setText("Login not found. Create a new login first.");
            return;
        }

        // Keep only the ID for the signed-in account; later queries use it to enforce ownership.
        activeUserId = userId;
        showDashboard(view);
    }

    public void createAccount(View view) {
        // New accounts are saved locally so the user can come back to the app later.
        EditText usernameInput = findViewById(R.id.usernameInput);
        EditText passwordInput = findViewById(R.id.passwordInput);
        TextView statusText = findViewById(R.id.loginStatusText);

        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        // Empty credentials are rejected here instead of creating an unusable account record.
        if (username.isEmpty() || password.isEmpty()) {
            statusText.setText("Choose a username and password.");
            return;
        }

        long userId = viewModel.createUser(username, password);
        if (userId < 0) {
            statusText.setText("That username already exists. Try logging in.");
            return;
        }

        // The returned database ID becomes the account context for every following screen.
        activeUserId = userId;
        showDashboard(view);
    }

    public void showDashboard(View view) {
        // Each screen is a small layout, so returning here also gives us a clean dashboard refresh.
        setContentView(R.layout.activity_dashboard);
        populateDashboard();
    }

    public void showAddWeight(View view) {
        editingWeightId = -1;
        setContentView(R.layout.activity_add_weight);

        // Most users will log today's weight, so the date is filled in for convenience.
        EditText dateInput = findViewById(R.id.weightDateInput);
        String today = new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(new Date());
        dateInput.setText(today);
    }

    public void showGoalWeight(View view) {
        setContentView(R.layout.activity_goal_weight);
        // Refill the form when a goal already exists so editing does not start with a blank value.
        Double goalWeight = viewModel.getGoalWeight(activeUserId);
        EditText goalInput = findViewById(R.id.goalWeightInput);
        if (goalWeight != null) {
            goalInput.setText(formatWeight(goalWeight));
        }
    }

    public void showProgress(View view) {
        setContentView(R.layout.activity_progress);
        // Progress is calculated from the newest saved entry rather than from a temporary field.
        updateProgressScreen();
    }

    public void showSettings(View view) {
        setContentView(R.layout.activity_sms_permission);

        // Phone settings are stored locally and restored whenever the settings screen opens.
        EditText phoneInput = findViewById(R.id.phoneNumberInput);
        phoneInput.setText(getSavedPhoneNumber());
        updateSmsStatus();
    }

    public void saveWeightEntry(View view) {
        TextView statusText = findViewById(R.id.weightStatusText);
        EditText dateInput = findViewById(R.id.weightDateInput);
        EditText weightInput = findViewById(R.id.dailyWeightInput);

        String entryDate = dateInput.getText().toString().trim();
        String weightText = weightInput.getText().toString().trim();

        // Check required fields before parsing so the error message points to the actual problem.
        if (entryDate.isEmpty() || weightText.isEmpty()) {
            statusText.setText("Enter both date and weight.");
            return;
        }

        double weight;
        try {
            // Parsing is kept separate from the range check so text and numeric errors are clear.
            weight = Double.parseDouble(weightText);
        } catch (NumberFormatException error) {
            statusText.setText("Weight must be a number.");
            return;
        }

        if (!WeightInputValidator.isValidWeight(weight)) {
            statusText.setText("Enter a weight between 1 and 1000 pounds.");
            return;
        }

        // The same screen supports adding and editing, while the repository
        // keeps the database operation separate from the screen logic.
        if (editingWeightId >= 0) {
            viewModel.updateWeight(activeUserId, editingWeightId, entryDate, weight);
            editingWeightId = -1;
        } else {
            viewModel.addWeight(activeUserId, entryDate, weight);
        }

        // After saving, the dashboard refreshes so the user immediately sees the latest data.
        sendGoalSmsIfNeeded(weight);
        showDashboard(view);
    }

    public void saveGoalWeight(View view) {
        TextView statusText = findViewById(R.id.goalStatusText);
        EditText goalInput = findViewById(R.id.goalWeightInput);
        String goalText = goalInput.getText().toString().trim();

        // A goal is optional, but a value that is saved must be a valid positive weight.
        if (goalText.isEmpty()) {
            statusText.setText("Enter a goal weight.");
            return;
        }

        try {
            double goalWeight = Double.parseDouble(goalText);
            if (!WeightInputValidator.isValidWeight(goalWeight)) {
                statusText.setText("Enter a goal weight between 1 and 1000 pounds.");
                return;
            }
            // Repository persistence means the goal is available to the dashboard and progress screen.
            viewModel.saveGoalWeight(activeUserId, goalWeight);
            showDashboard(view);
        } catch (NumberFormatException error) {
            statusText.setText("Goal weight must be a number.");
        }
    }

    public void requestSmsPermission(View view) {
        // Save the phone number first so permission and notification setup happen in one flow.
        saveNotificationPhone(view);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            updateSmsStatusText("SMS permission is enabled. Goal weight notifications can be sent.");
            return;
        }

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST);
    }

    public void declineSmsPermission(View view) {
        // Tracking remains available even when the optional text-message feature is declined.
        updateSmsStatusText("SMS permission declined. The app will still track weight, but text notifications will stay off.");
    }

    public void saveNotificationPhone(View view) {
        EditText phoneInput = findViewById(R.id.phoneNumberInput);
        String phone = phoneInput.getText().toString().trim();
        if (!WeightInputValidator.isValidPhoneNumber(phone)) {
            updateSmsStatusText("Enter a valid phone number with 10 to 15 digits.");
            return;
        }
        // SharedPreferences is appropriate here because this is a small device setting, not app data.
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putString(PREF_PHONE, phone).apply();
        updateSmsStatusText("Phone number saved. SMS notifications require permission to send.");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST) {
            // Android returns the permission result asynchronously, so update the screen from this callback.
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                updateSmsStatusText("SMS permission granted. A text can be sent when the goal weight is reached.");
            } else {
                updateSmsStatusText("SMS permission denied. The app remains usable without text notifications.");
            }
        }
    }

    private void populateDashboard() {
        // Refresh the list from the database so edits and deletes are immediately visible.
        TextView progressSummary = findViewById(R.id.progressSummary);
        List<WeightEntry> weights = viewModel.getWeights(activeUserId);
        Double goalWeight = viewModel.getGoalWeight(activeUserId);

        RecyclerView weightList = findViewById(R.id.weightList);
        // RecyclerView reuses row views, which scales better than creating a new view for every record.
        weightList.setLayoutManager(new LinearLayoutManager(this));
        weightList.setAdapter(new WeightEntryAdapter(weights, new WeightEntryAdapter.OnWeightActionListener() {
            @Override
            public void onEdit(WeightEntry entry) {
                editWeightEntry(entry.getId());
            }

            @Override
            public void onDelete(WeightEntry entry) {
                // Ownership is checked again in the data layer before deletion.
                viewModel.deleteWeight(activeUserId, entry.getId());
                populateDashboard();
            }
        }));

        if (weights.isEmpty()) {
            progressSummary.setText("Goal: " + formatGoal(goalWeight) + " • Latest entry: no entries yet");
        } else {
            // getWeights sorts newest first, so the first item is the current summary value.
            WeightEntry latest = weights.get(0);
            progressSummary.setText("Goal: " + formatGoal(goalWeight)
                    + " • Latest entry: " + formatWeight(latest.getWeight()) + " lb"
                    + " • " + buildGoalMessage(goalWeight, latest.getWeight()));
        }
    }

    private void editWeightEntry(long entryId) {
        // Loading the saved entry into the form lets the user fix a typo without retyping everything.
        WeightEntry entry = viewModel.getWeight(activeUserId, entryId);
        if (entry == null) {
            return;
        }

        editingWeightId = entryId;
        setContentView(R.layout.activity_add_weight);
        TextView title = findViewById(R.id.addWeightTitle);
        EditText dateInput = findViewById(R.id.weightDateInput);
        EditText weightInput = findViewById(R.id.dailyWeightInput);

        title.setText("Update Daily Weight");
        dateInput.setText(entry.getEntryDate());
        weightInput.setText(formatWeight(entry.getWeight()));
    }

    private void updateProgressScreen() {
        TextView currentWeightSummary = findViewById(R.id.currentWeightSummary);
        TextView goalWeightSummary = findViewById(R.id.goalWeightSummary);
        TextView progressMessage = findViewById(R.id.progressMessage);
        List<WeightEntry> weights = viewModel.getWeights(activeUserId);
        Double goalWeight = viewModel.getGoalWeight(activeUserId);

        if (weights.isEmpty()) {
            currentWeightSummary.setText("Current weight: no entries yet");
            goalWeightSummary.setText("Goal weight: " + formatGoal(goalWeight));
            progressMessage.setText("Add a daily weight to begin tracking progress.");
            return;
        }

        // The same newest entry drives both the dashboard summary and the progress screen.
        double latestWeight = weights.get(0).getWeight();
        currentWeightSummary.setText("Current weight: " + formatWeight(latestWeight) + " lb");
        goalWeightSummary.setText("Goal weight: " + formatGoal(goalWeight));
        progressMessage.setText(buildGoalMessage(goalWeight, latestWeight));
    }

    private void sendGoalSmsIfNeeded(double latestWeight) {
        // SMS is optional, so the app checks the goal, phone number, and permission before sending.
        Double goalWeight = viewModel.getGoalWeight(activeUserId);
        String phoneNumber = getSavedPhoneNumber();
        boolean hasPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;

        if (goalWeight == null || latestWeight > goalWeight || phoneNumber.isEmpty() || !hasPermission) {
            return;
        }

        SmsManager.getDefault().sendTextMessage(
                phoneNumber,
                null,
                "You reached your goal weight. Great job staying consistent!",
                null,
                null
        );
    }

    private void updateSmsStatus() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            updateSmsStatusText("SMS permission is currently enabled.");
        } else {
            updateSmsStatusText("SMS permission is not enabled yet.");
        }
    }

    private void updateSmsStatusText(String message) {
        TextView status = findViewById(R.id.smsPermissionStatus);
        if (status != null) {
            status.setText(message);
        }
    }

    private String getSavedPhoneNumber() {
        // Keeping this lookup in one method avoids repeating the preference key throughout the activity.
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return preferences.getString(PREF_PHONE, "");
    }

    private String formatGoal(Double goalWeight) {
        if (goalWeight == null) {
            return "not set";
        }
        return formatWeight(goalWeight) + " lb";
    }

    private String buildGoalMessage(Double goalWeight, double latestWeight) {
        if (goalWeight == null) {
            return "Set a goal to track progress.";
        }
        if (latestWeight <= goalWeight) {
            return "Goal reached!";
        }
        return formatWeight(latestWeight - goalWeight) + " lb from goal.";
    }

    private String formatWeight(double weight) {
        if (weight == Math.rint(weight)) {
            return String.format(Locale.US, "%.0f", weight);
        }
        return String.format(Locale.US, "%.1f", weight);
    }

}
