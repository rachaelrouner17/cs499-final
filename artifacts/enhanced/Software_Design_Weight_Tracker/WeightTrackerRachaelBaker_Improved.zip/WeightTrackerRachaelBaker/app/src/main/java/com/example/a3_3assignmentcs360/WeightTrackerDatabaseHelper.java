package com.example.a3_3assignmentcs360;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class WeightTrackerDatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "smart_weight_tracker.db";
    private static final int DATABASE_VERSION = 1;
    private static final int PASSWORD_ITERATIONS = 120000;
    private static final int PASSWORD_KEY_LENGTH = 256;
    private static final int PASSWORD_SALT_LENGTH = 16;

    private static final String TABLE_USERS = "users";
    private static final String TABLE_DAILY_WEIGHTS = "daily_weights";
    private static final String TABLE_GOAL_WEIGHTS = "goal_weights";

    public WeightTrackerDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // The three tables keep account, daily weight, and goal data separated but connected.
        db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "username TEXT UNIQUE NOT NULL, "
                + "password TEXT NOT NULL)");

        db.execSQL("CREATE TABLE " + TABLE_DAILY_WEIGHTS + " ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "user_id INTEGER NOT NULL, "
                + "entry_date TEXT NOT NULL, "
                + "weight REAL NOT NULL, "
                + "FOREIGN KEY(user_id) REFERENCES " + TABLE_USERS + "(id))");

        db.execSQL("CREATE TABLE " + TABLE_GOAL_WEIGHTS + " ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "user_id INTEGER UNIQUE NOT NULL, "
                + "goal_weight REAL NOT NULL, "
                + "FOREIGN KEY(user_id) REFERENCES " + TABLE_USERS + "(id))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // This class-project migration recreates the small local schema when its version changes.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DAILY_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    public long createUser(String username, String password) {
        // Store a hashed password instead of the plain text value the user typed.
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", hashPassword(password));
        return getWritableDatabase().insert(TABLE_USERS, null, values);
    }

    public long validateUser(String username, String password) {
        // Query the stored hash only; the plain-text password is never saved or returned.
        String[] columns = {"id", "password"};
        String selection = "username = ?";
        String[] args = {username};

        try (Cursor cursor = getReadableDatabase().query(TABLE_USERS, columns, selection, args, null, null, null)) {
            if (cursor.moveToFirst() && verifyPassword(password, cursor.getString(1))) {
                return cursor.getLong(0);
            }
        }

        return -1;
    }

    public long addWeight(long userId, String entryDate, double weight) {
        // Associate every entry with its owner so separate accounts cannot share records.
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("entry_date", entryDate);
        values.put("weight", weight);
        return getWritableDatabase().insert(TABLE_DAILY_WEIGHTS, null, values);
    }

    public int updateWeight(long userId, long entryId, String entryDate, double weight) {
        // Including user_id in the WHERE clause prevents editing another user's entry by ID.
        ContentValues values = new ContentValues();
        values.put("entry_date", entryDate);
        values.put("weight", weight);
        String selection = "id = ? AND user_id = ?";
        String[] args = {String.valueOf(entryId), String.valueOf(userId)};
        return getWritableDatabase().update(TABLE_DAILY_WEIGHTS, values, selection, args);
    }

    public int deleteWeight(long userId, long entryId) {
        // The ownership condition protects deletion in the same way as the update operation.
        String selection = "id = ? AND user_id = ?";
        String[] args = {String.valueOf(entryId), String.valueOf(userId)};
        return getWritableDatabase().delete(TABLE_DAILY_WEIGHTS, selection, args);
    }

    public List<WeightEntry> getWeights(long userId) {
        // The dashboard needs the newest entries first so the latest progress is easy to see.
        List<WeightEntry> weights = new ArrayList<>();
        String[] columns = {"id", "entry_date", "weight"};
        String selection = "user_id = ?";
        String[] args = {String.valueOf(userId)};

        try (Cursor cursor = getReadableDatabase().query(TABLE_DAILY_WEIGHTS, columns, selection, args, null, null, "entry_date DESC, id DESC")) {
            while (cursor.moveToNext()) {
                weights.add(new WeightEntry(cursor.getLong(0), cursor.getString(1), cursor.getDouble(2)));
            }
        }

        return weights;
    }

    public WeightEntry getWeight(long userId, long entryId) {
        // Return an entry only when both its record ID and owner match the active account.
        String[] columns = {"id", "entry_date", "weight"};
        String selection = "id = ? AND user_id = ?";
        String[] args = {String.valueOf(entryId), String.valueOf(userId)};
        try (Cursor cursor = getReadableDatabase().query(TABLE_DAILY_WEIGHTS, columns, selection, args, null, null, null)) {
            if (cursor.moveToFirst()) {
                return new WeightEntry(cursor.getLong(0), cursor.getString(1), cursor.getDouble(2));
            }
        }

        return null;
    }

    public void saveGoalWeight(long userId, double goalWeight) {
        // Each user only needs one active goal, so this updates the existing goal when possible.
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("goal_weight", goalWeight);

        SQLiteDatabase db = getWritableDatabase();
        int updated = db.update(TABLE_GOAL_WEIGHTS, values, "user_id = ?", new String[]{String.valueOf(userId)});
        if (updated == 0) {
            db.insert(TABLE_GOAL_WEIGHTS, null, values);
        }
    }

    public Double getGoalWeight(long userId) {
        String[] columns = {"goal_weight"};
        try (Cursor cursor = getReadableDatabase().query(TABLE_GOAL_WEIGHTS, columns, "user_id = ?", new String[]{String.valueOf(userId)}, null, null, null)) {
            if (cursor.moveToFirst()) {
                return cursor.getDouble(0);
            }
        }

        return null;
    }

    private String hashPassword(String password) {
        // A unique salt and repeated key derivation make copied password data
        // more difficult to reuse than a single fast hash.
        byte[] salt = new byte[PASSWORD_SALT_LENGTH];
        new SecureRandom().nextBytes(salt);

        try {
            PBEKeySpec keySpec = new PBEKeySpec(
                    password.toCharArray(), salt, PASSWORD_ITERATIONS, PASSWORD_KEY_LENGTH
            );
            byte[] derivedKey = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(keySpec)
                    .getEncoded();
            keySpec.clearPassword();
            return "pbkdf2$" + PASSWORD_ITERATIONS + "$"
                    + Base64.encodeToString(salt, Base64.NO_WRAP) + "$"
                    + Base64.encodeToString(derivedKey, Base64.NO_WRAP);
        } catch (Exception error) {
            throw new IllegalStateException("Secure password hashing is unavailable on this device.", error);
        }
    }

    private boolean verifyPassword(String password, String storedPassword) {
        if (storedPassword == null) {
            return false;
        }

        // Existing class-project accounts used the earlier SHA-256 format.
        // Keeping this fallback prevents an upgrade from locking out those accounts.
        if (!storedPassword.startsWith("pbkdf2$")) {
            return MessageDigest.isEqual(
                    storedPassword.getBytes(StandardCharsets.UTF_8),
                    hashLegacyPassword(password).getBytes(StandardCharsets.UTF_8)
            );
        }

        String[] parts = storedPassword.split("\\$", -1);
        if (parts.length != 4) {
            return false;
        }

        try {
            int iterations = Integer.parseInt(parts[1]);
            byte[] salt = Base64.decode(parts[2], Base64.NO_WRAP);
            byte[] expectedKey = Base64.decode(parts[3], Base64.NO_WRAP);
            PBEKeySpec keySpec = new PBEKeySpec(
                    password.toCharArray(), salt, iterations, expectedKey.length * 8
            );
            byte[] actualKey = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(keySpec)
                    .getEncoded();
            keySpec.clearPassword();
            return MessageDigest.isEqual(actualKey, expectedKey);
        } catch (Exception error) {
            return false;
        }
    }

    private String hashLegacyPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder builder = new StringBuilder();
            for (byte value : hashedBytes) {
                builder.append(String.format(Locale.US, "%02x", value));
            }
            return builder.toString();
        } catch (NoSuchAlgorithmException error) {
            throw new IllegalStateException("SHA-256 is not available on this device.", error);
        }
    }
}
