package com.example.a3_3assignmentcs360;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

import java.util.List;

/**
 * Holds application data operations outside the activity lifecycle.
 * The activity remains responsible for displaying screens, while this
 * ViewModel coordinates the repository used by those screens.
 */
public final class WeightTrackerViewModel extends AndroidViewModel {
    private final WeightRepository repository;

    public WeightTrackerViewModel(@NonNull Application application) {
        super(application);
        repository = new WeightRepository(application);
    }

    public long createUser(String username, String password) {
        // The ViewModel exposes a small, screen-friendly API while the repository owns data access.
        return repository.createUser(username, password);
    }

    public long validateUser(String username, String password) {
        // Login validation returns only the account ID needed by the activity.
        return repository.validateUser(username, password);
    }

    public long addWeight(long userId, String entryDate, double weight) {
        // All weight changes pass through the active user's ID.
        return repository.addWeight(userId, entryDate, weight);
    }

    public int updateWeight(long userId, long entryId, String entryDate, double weight) {
        // Update and delete operations use both IDs to prevent cross-account changes.
        return repository.updateWeight(userId, entryId, entryDate, weight);
    }

    public int deleteWeight(long userId, long entryId) {
        return repository.deleteWeight(userId, entryId);
    }

    public List<WeightEntry> getWeights(long userId) {
        return repository.getWeights(userId);
    }

    public WeightEntry getWeight(long userId, long entryId) {
        return repository.getWeight(userId, entryId);
    }

    public void saveGoalWeight(long userId, double goalWeight) {
        repository.saveGoalWeight(userId, goalWeight);
    }

    public Double getGoalWeight(long userId) {
        return repository.getGoalWeight(userId);
    }
}
