package com.example.a3_3assignmentcs360;

public class WeightEntry {
    private final long id;
    private final String entryDate;
    private final double weight;

    public WeightEntry(long id, String entryDate, double weight) {
        this.id = id;
        this.entryDate = entryDate;
        this.weight = weight;
    }

    public long getId() {
        return id;
    }

    public String getEntryDate() {
        return entryDate;
    }

    public double getWeight() {
        return weight;
    }
}
